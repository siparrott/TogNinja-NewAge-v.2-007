-- Complete Database Export SQL Dump
-- Generated: 2025-08-24T08:56:23.451Z
-- Source: Neon Database

-- Disable foreign key checks during import
SET session_replication_role = replica;


-- Re-enable foreign key checks
SET session_replication_role = DEFAULT;
